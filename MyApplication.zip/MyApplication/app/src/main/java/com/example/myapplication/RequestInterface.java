package com.example.myapplication;
import retrofit2.Call;
import retrofit2.http.GET;

public interface RequestInterface {
        @GET("
https://newsapi.org/v2/everything?q=bitcoin&from=2019-01-15&sortBy=publishedAt&apiKey=092a0b7146a94c4e950e7812f504745c")
        Call<Newsreadloader> getJSON();
    }

